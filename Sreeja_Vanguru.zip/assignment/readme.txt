-> To run the 3 searches, open the project in a python environment
-> Open terminal, enter python3 GBFS_inputs_based.py
-> Click enter, enter python3 GBFS_motion_based.py
-> Click enter, enter python3 IDS.py
-> Once you run these 3 files, it will generate the 5 task trees for 
    each respective files.
